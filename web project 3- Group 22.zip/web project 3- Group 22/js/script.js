// Mock données KPI Dashboard
const kpiData = {
  avgSalary: 16134.49,
  avgCheck: 2149.35,
  netProfit: 119408,
  planning: 109,
  pie: [
    { label: "<100%", value: 4 },
    { label: ">100%", value: 4 },
    { label: ">130%", value: 3 },
  ],
  managersKpi: [
    { month: "Jan", value: 70000 },
    { month: "Feb", value: 100000 },
    { month: "Mar", value: 110000 },
    { month: "Apr", value: 90000 },
    { month: "May", value: 85000 },
    { month: "Jun", value: 99000 },
    { month: "Jul", value: 110000 },
    { month: "Aug", value: 120000 },
    { month: "Sep", value: 128000 },
    { month: "Oct", value: 140000 },
    { month: "Nov", value: 145000 },
    { month: "Dec", value: 155000 },
  ],
  mastersKpi: [
    { month: "Jan", value: 30 },
    { month: "Feb", value: 29 },
    { month: "Mar", value: 32 },
    { month: "Apr", value: 25 },
    { month: "May", value: 32 },
    { month: "Jun", value: 34 },
    { month: "Jul", value: 28 },
    { month: "Aug", value: 30 },
    { month: "Sep", value: 35 },
    { month: "Oct", value: 33 },
    { month: "Nov", value: 28 },
    { month: "Dec", value: 26 },
  ],
};

// Mock employés
let employees = ["John Dah", "Will Smith","Babou Bado","Joao Felix","Kylian Nykiema","Poko Ouedraogo","Abdoul Aziz ","Kabore Keneth",];

// Mock données Contacts
const contacts = [
  { name: "Fatima Ouedraogo", email: "fatimaodg@gmail.com", phone: "06 12 34 56 ", company: "Fatima copagny", lastContact: "2025-07-10" },
  { name: "Bernard Martin", email: "bernardmartin13@gmail.com", phone: "77 65 43 21", company: "FasoTech SARL", lastContact: "2025-07-15" },
  { name: "Céline Nana", email: "celine9@gmail.com", phone: " 65 23 67 89", company: "Celina Marquet ", lastContact: "2025-07-18" }
];

// Mock données Leads
const leads = [
  { name: "Karelle Kabore", email: "karellek5@gmail.com", source: "Web", status: "New", created: "2025-07-20" },
  { name: "Sarifatou Roamba ", email: "roambasarifatou9@gmail.com", source: "Referral", status: "Contacted", created: "2025-07-19" },
  { name: "Gloria Sawadogo", email: "glorias@gmail.com", source: "Event", status: "Qualified", created: "2025-07-18" },
];

// Affichage initial KPIs
document.getElementById("avgSalary").textContent = `${kpiData.avgSalary.toLocaleString('fr-FR')} franc CFA`;
document.getElementById("avgCheck").textContent = `${kpiData.avgCheck.toLocaleString('fr-FR')} franc CFA`;
document.getElementById("netProfit").textContent = `${kpiData.netProfit.toLocaleString('fr-FR')} franc CFA`;
document.getElementById("planningValue").textContent = `${kpiData.planning}%`;

// Affichage liste employés
function renderEmployees() {
  const ul = document.getElementById("employeeList");
  ul.innerHTML = "";
  employees.forEach(name => {
    const li = document.createElement("li");
    li.textContent = name;
    ul.appendChild(li);
  });
}
renderEmployees();

// Ajout / suppression employés via prompt
document.getElementById("add-employee").addEventListener("click", () => {
  const name = prompt("Nom de l'employé à ajouter :");
  if (name && name.trim() !== "") {
    employees.push(name.trim());
    renderEmployees();
  }
});
document.getElementById("fire-employee").addEventListener("click", () => {
  if (employees.length === 0) {
    alert("Aucun employé à supprimer.");
    return;
  }
  const name = prompt("Nom exact de l'employé à supprimer :\n" + employees.join(", "));
  if (name && employees.includes(name.trim())) {
    employees = employees.filter(e => e !== name.trim());
    renderEmployees();
  }
});

// Navigation entre sections
function showSection(sectionId, btn) {
  document.querySelectorAll(".section").forEach(s => s.classList.remove("active-section"));
  document.getElementById(sectionId).classList.add("active-section");
  
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active-btn"));
  if(btn) btn.classList.add("active-btn");
}
window.showSection = showSection; // globale pour HTML

// Render contacts table
function renderContacts() {
  const tbody = document.querySelector("#contactsTable tbody");
  tbody.innerHTML = "";
  contacts.forEach(c => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${c.name}</td>
      <td>${c.email}</td>
      <td>${c.phone}</td>
      <td>${c.company}</td>
      <td>${c.lastContact}</td>
    `;
    tbody.appendChild(tr);
  });
}
renderContacts();

// Render leads table
function renderLeads() {
  const tbody = document.querySelector("#leadsTable tbody");
  tbody.innerHTML = "";
  leads.forEach(lead => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${lead.name}</td>
      <td>${lead.email}</td>
      <td>${lead.source}</td>
      <td>${lead.status}</td>
      <td>${lead.created}</td>
    `;
    tbody.appendChild(tr);
  });
}
renderLeads();

// Les graphes Chart.js
let pieChart, lineChart, barChart;
let currentTab = "managers";

const ctxPie = document.getElementById("pieChart").getContext("2d");
const ctxLine = document.getElementById("lineChart").getContext("2d");
const ctxBar = document.getElementById("barChart").getContext("2d");

function renderCharts() {
  // Camembert
  if(pieChart) pieChart.destroy();
  pieChart = new Chart(ctxPie, {
    type: "pie",
    data: {
      labels: kpiData.pie.map(p => p.label),
      datasets: [{
        data: kpiData.pie.map(p => p.value),
        backgroundColor: ['#ede9fe','#a7bffa','#7c3aed'],
      }],
    },
    options: {
      responsive: false,
      plugins: { legend: { display: false } },
      cutout: "40%",
    },
  });

  // Graphique ligne KPIs managers
  if(lineChart) lineChart.destroy();
  lineChart = new Chart(ctxLine, {
    type: "line",
    data: {
      labels: kpiData.managersKpi.map(d => d.month),
      datasets: [{
        label: "KPIs Managers",
        data: kpiData.managersKpi.map(d => d.value),
        borderColor: "#6d28d9",
        backgroundColor: "rgba(109,40,217,0.2)",
        fill: true,
        tension: 0.4,
        pointRadius: 5,
      }],
    },
    options: {
      responsive: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true },
      },
    },
  });

  // Graphique barres KPIs masters
  if(barChart) barChart.destroy();
  barChart = new Chart(ctxBar, {
    type: "bar",
    data: {
      labels: kpiData.mastersKpi.map(d => d.month),
      datasets: [{
        label: "KPIs Masters",
        data: kpiData.mastersKpi.map(d => d.value),
        backgroundColor: "#7c3aed",
      }],
    },
    options: {
      responsive: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true }
      }
    },
  });
}
renderCharts();

// Basculer l’affichage des KPIs si on veut plus tard (code prêt à étendre)
document.getElementById("managers-tab").addEventListener("click", () => {
  currentTab = "managers";
  document.getElementById("managers-tab").classList.add("active-toggle");
  document.getElementById("masters-tab").classList.remove("active-toggle");
});

document.getElementById("masters-tab").addEventListener("click", () => {
  currentTab = "masters";
  document.getElementById("masters-tab").classList.add("active-toggle");
  document.getElementById("managers-tab").classList.remove("active-toggle");
});
// --- Données fictives pour la section Stats ---
const statsData = {
  monthlySales: [
    { month: "Jan", sales: 12000 },
    { month: "Feb", sales: 15000 },
    { month: "Mar", sales: 13000 },
    { month: "Apr", sales: 17000 },
    { month: "May", sales: 14000 },
    { month: "Jun", sales: 18000 },
    { month: "Jul", sales: 16000 },
    { month: "Aug", sales: 19000 },
    { month: "Sep", sales: 17500 },
    { month: "Oct", sales: 20000 },
    { month: "Nov", sales: 21000 },
    { month: "Dec", sales: 23000 },
  ],
  totalClients: 3,
  totalLeads: 3,
  netRevenue: 1234500
};

function renderStats() {
  const statsSection = document.getElementById("Stats");
  // Nettoyer section
  statsSection.innerHTML = `
    <h2>Stats</h2>
    <div class="stats-summary">
      <div class="stat-box">
        <h3>Total Clients</h3>
        <p>${statsData.totalClients}</p>
      </div>
      <div class="stat-box">
        <h3>Total Leads</h3>
        <p>${statsData.totalLeads}</p>
      </div>
      <div class="stat-box">
        <h3>Net Revenue</h3>
        <p>${statsData.netRevenue.toLocaleString('fr-FR')} CFA</p>
      </div>
    </div>
    <canvas id="salesChart" width="800" height="300"></canvas>
  `;

  // Graphique ventes mensuelles
  const ctx = document.getElementById("salesChart").getContext("2d");
  new Chart(ctx, {
    type: "bar",
    data: {
      labels: statsData.monthlySales.map(d => d.month),
      datasets: [{
        label: "Ventes mensuelles",
        data: statsData.monthlySales.map(d => d.sales),
        backgroundColor: "#6d28d9",
      }]
    },
    options: {
      responsive: false,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
}

// --- Contenu basique pour la section Settings ---
function renderSettings() {
  const settingsSection = document.getElementById("Settings");
  settingsSection.innerHTML = `
    <h2>Settings</h2>
    <form id="settingsForm" class="settings-form">
      <label for="username">Nom utilisateur</label>
      <input type="text" id="username" name="username" value="" required />
      
      <label for="email">Email</label>
      <input type="email" id="email" name="email" value="" required />
      
      <label for="notifications">Notifications</label>
      <select id="notifications" name="notifications">
        <option value="all">Toutes</option>
        <option value="important">Uniquement importantes</option>
        <option value="none">Aucune</option>
      </select>
      
      <button type="submit">Sauvegarder</button>
    </form>
    <div id="settingsMessage" class="settings-message"></div>
  `;

  document.getElementById("settingsForm").addEventListener("submit", e => {
    e.preventDefault();
    // Simuler sauvegarde
    document.getElementById("settingsMessage").textContent = "Paramètres sauvegardés avec succès.";
    setTimeout(() => {
      document.getElementById("settingsMessage").textContent = "";
    }, 3000);
  });
}

// Appeler ces fonctions au chargement du script
renderStats();
renderSettings();

